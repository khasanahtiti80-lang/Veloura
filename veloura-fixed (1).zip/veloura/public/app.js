const app=document.getElementById('app');let user=null;
const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const md=s=>h(s).replace(/^#{1,3} (.*)$/gm,'<h3>$1</h3>').replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/^(?:- |\* )(.*)$/gm,'<li>$1</li>').replace(/(?:<li>.*<\/li>\n?)+/g,m=>'<ul>'+m+'</ul>').replace(/\n{2,}/g,'<br><br>').replace(/<\/(h3|ul)>\n/g,'</$1>');
async function api(p,m='GET',b){const r=await fetch('/api'+p,{method:m,headers:b?{'content-type':'application/json'}:{},body:b?JSON.stringify(b):undefined});
 const d=await r.json().catch(()=>({}));if(!r.ok){if(r.status===401&&user){user=null;route()}throw new Error(d.error||'Terjadi kesalahan')}return d}
function toast(t,e){const d=document.createElement('div');d.className='toast'+(e?' e':'');d.textContent=t;document.body.append(d);setTimeout(()=>d.remove(),3200)}
const fmt=d=>new Date(d.replace(' ','T')+'Z').toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'});
const LBL={branding:'Personal Branding',content:'Content Studio',evaluate:'Brand Evaluator',interview:'Interview'};
const TOOLS={
 branding:{t:'AI Personal Branding Generator',s:'Ceritakan diri Anda; Veloura merumuskan positioning, tagline, bio, dan rencana aksi.',btn:'Buat strategi brand',
  f:[['skills','Keahlian dan kekuatan','ta'],['experience','Pengalaman utama','ta'],['values','Nilai dan kepribadian','ta'],['audience','Target audiens (mis. rekruter startup)','tx']]},
 content:{t:'Content Studio',s:'Konten profesional siap posting sesuai platform dan gaya Anda.',btn:'Tulis konten',
  f:[['platform','Platform','sel',['LinkedIn','Instagram','Twitter/X','Artikel blog','Email profesional']],['topic','Topik atau pesan utama','ta'],['tone','Gaya bahasa','sel',['Profesional','Hangat','Inspiratif','Tegas','Santai']],['goal','Tujuan konten','tx']]},
 evaluate:{t:'Brand Evaluator',s:'Tempel bio atau ringkasan profil Anda untuk dinilai dan diperbaiki.',btn:'Evaluasi brand saya',
  f:[['text','Teks brand Anda (bio, ringkasan LinkedIn, pitch)','ta'],['target','Posisi atau audiens yang dituju','tx']]}};
const field=([k,l,t,o])=>`<label for="${k}">${h(l)}</label>`+(t==='ta'?`<textarea id="${k}" name="${k}" required maxlength="2500"></textarea>`:t==='sel'?`<select id="${k}" name="${k}">${o.map(x=>`<option>${h(x)}</option>`).join('')}</select>`:`<input id="${k}" name="${k}" required maxlength="2500">`);
function evalView(j){let d;try{d=JSON.parse(j)}catch{return md(j)}const L=a=>'<ul>'+(a||[]).map(x=>`<li>${h(x)}</li>`).join('')+'</ul>';
 return `<div class="stat">${h(d.score)}<small class="score-unit"> / 100</small></div><p>${h(d.summary)}</p>`+
 Object.entries(d.scores||{}).map(([k,v])=>`<div class="row"><span>${h(k)}</span><span class="score-track"><div class="bar"><i data-w="${Math.max(0,Math.min(100,Math.round(+v||0)))}"></i></div></span></div>`).join('')+
 `<h3>Kekuatan</h3>${L(d.strengths)}<h3>Perbaikan</h3>${L(d.improvements)}<h3>Versi yang disarankan</h3><p>${h(d.rewrite)}</p>`}
const show=(type,o)=>type==='evaluate'?evalView(o):md(o);
function fillBars(){document.querySelectorAll('.bar i[data-w]').forEach(i=>{i.className='w-'+Math.max(0,Math.min(100,Math.round(Number(i.dataset.w)||0)))})}
const NAV=[['dash','Dashboard'],['branding','Personal Branding'],['content','Content Studio'],['interview','Interview Simulator'],['evaluate','Brand Evaluator'],['history','Riwayat'],['settings','Profil']];
function shell(cur,body){app.innerHTML=`<div class="shell"><nav class="side"><div class="logo">Veloura</div>${NAV.map(([k,l])=>`<a href="#/${k}" class="${cur===k?'on':''}">${l}</a>`).join('')}<div class="sp"></div><a href="#" data-act="logout">Keluar</a></nav><main>${body}</main></div>`;fillBars()}
function authView(mode='login'){const r=mode==='register';app.innerHTML=`<div class="auth"><div class="card"><div class="logo">Veloura</div><p class="sub centered">Studio brand pribadi untuk karier Anda</p>
<form data-form="${mode}">${r?'<label for="name">Nama lengkap</label><input id="name" name="name" required maxlength="80" autocomplete="name">':''}
<label for="email">Email</label><input id="email" name="email" type="email" required autocomplete="email"><label for="password">Kata sandi${r?' (min. 8 karakter)':''}</label><input id="password" name="password" type="password" required minlength="${r?8:1}" autocomplete="${r?'new':'current'}-password">
<div class="err" id="err"></div><button class="gold full-width">${r?'Buat akun':'Masuk'}</button></form>
<p class="mu centered">${r?'Sudah punya akun?':'Belum punya akun?'} <a href="#" data-act="${r?'tologin':'toreg'}">${r?'Masuk':'Daftar'}</a></p></div></div>`}
async function dash(){const d=await api('/stats'),c=d.counts;shell('dash',`<h1>Selamat datang, ${h(user.name.split(' ')[0])}</h1><p class="sub">Ringkasan aktivitas brand Anda.</p>
<div class="grid">${Object.entries(LBL).map(([k,l])=>`<div class="card"><div class="stat">${c[k]||0}</div><span class="mu">${l}</span></div>`).join('')}</div>
<div class="card"><h2>Mulai dengan</h2><a href="#/branding"><button class="gold">Buat strategi brand</button></a><a href="#/content"><button class="ghost">Tulis konten</button></a><a href="#/interview"><button class="ghost">Latihan wawancara</button></a></div>
<div class="card"><h2>Terbaru</h2>${d.recent.length?d.recent.map(r=>`<div class="row"><a href="#/history/${r.id}">${h(r.title)}</a><small>${fmt(r.created)}</small></div>`).join(''):'<p class="mu">Belum ada hasil. Pilih satu fitur di atas untuk memulai.</p>'}</div>`)}
function tool(k){const T=TOOLS[k];shell(k,`<h1>${T.t}</h1><p class="sub">${T.s}</p><div class="card"><form data-form="tool" data-tool="${k}">${T.f.map(field).join('')}<div class="err" id="err"></div><button class="gold">${T.btn}</button></form></div><div id="out"></div>`)}
function interview(){const s=window.iv;if(!s)return shell('interview',`<h1>Interview Simulator</h1><p class="sub">Jawab 5 pertanyaan, dapatkan umpan balik tiap jawaban dan ringkasan akhir.</p><div class="card"><form data-form="ivstart"><label for="role">Posisi yang dilamar</label><input id="role" name="role" required maxlength="100"><label for="level">Level</label><select id="level" name="level"><option>Fresh graduate</option><option>Junior</option><option>Menengah</option><option>Senior</option></select><div class="err" id="err"></div><button class="gold">Mulai simulasi</button></form></div>`);
 const q=s.qs[s.qs.length-1];shell('interview',`<h1>Pertanyaan ${s.qs.length} dari 5</h1><p class="sub">${h(s.role)} · ${h(s.level)}</p><div class="card"><h2>${h(q)}</h2>${s.fb?`<div class="out">${md(s.fb)}</div>${s.qs.length<5?'<button class="gold" data-act="ivnext">Pertanyaan berikutnya</button>':'<button class="gold" data-act="ivend">Selesai dan simpan ringkasan</button>'}`:`<form data-form="ivans"><label for="answer">Jawaban Anda</label><textarea id="answer" name="answer" required maxlength="2500"></textarea><div class="err" id="err"></div><button class="gold">Kirim jawaban</button></form>`}<button class="ghost" data-act="ivquit">Batalkan sesi</button></div>`)}
async function ivq(){const s=window.iv;const r=await api('/ai/interview/question','POST',{role:s.role,level:s.level,asked:s.qs.join(' | ')});s.qs.push(r.output);s.fb=null;interview()}
async function hist(id){if(id){const{item}=(await api('/history/'+id));return shell('history',`<h1>${h(item.title)}</h1><p class="sub">${LBL[item.type]||item.type} · ${fmt(item.created)}</p><div class="card out">${show(item.type,item.output)}</div><button class="ghost" data-act="copy" data-id="${item.id}">Salin teks</button><a href="#/history"><button class="ghost">Kembali</button></a><button class="danger" data-act="del" data-id="${item.id}">Hapus</button>`)}
 const t=location.hash.split('?t=')[1]||'',{items}=await api('/history'+(t?'?type='+t:''));
 shell('history',`<h1>Riwayat</h1><p class="sub">Semua hasil tersimpan otomatis.</p><div class="card"><div>${['',...Object.keys(LBL)].map(k=>`<a href="#/history${k?'?t='+k:''}" class="tag">${k?LBL[k]:'Semua'}</a>`).join('')}</div>${items.length?items.map(r=>`<div class="row"><span><a href="#/history/${r.id}">${h(r.title)}</a><br><small>${LBL[r.type]||r.type} · ${fmt(r.created)}</small></span><button class="danger" data-act="del" data-id="${r.id}">Hapus</button></div>`).join(''):'<p class="mu">Belum ada riwayat di kategori ini.</p>'}</div>`)}
function settings(){shell('settings',`<h1>Profil</h1><p class="sub">Informasi ini membuat hasil AI lebih sesuai dengan Anda.</p>
<div class="card"><form data-form="profile"><label for="name">Nama</label><input id="name" name="name" required value="${h(user.name)}"><label for="headline">Headline profesional</label><input id="headline" name="headline" value="${h(user.headline)}"><label for="industry">Industri</label><input id="industry" name="industry" value="${h(user.industry)}"><label for="goals">Tujuan karier</label><textarea id="goals" name="goals">${h(user.goals)}</textarea><label for="tone">Gaya bahasa pilihan</label><input id="tone" name="tone" value="${h(user.tone)}" placeholder="mis. hangat dan lugas"><button class="gold">Simpan profil</button></form></div>
<div class="card"><h2>Ganti kata sandi</h2><form data-form="pw"><label for="password">Kata sandi saat ini</label><input id="password" name="password" type="password" required><label for="newPassword">Kata sandi baru (min. 8)</label><input id="newPassword" name="newPassword" type="password" minlength="8" required><button class="gold">Ubah kata sandi</button></form></div>
<div class="card"><h2>Hapus akun</h2><p class="mu">Seluruh data dan riwayat dihapus permanen.</p><form data-form="delacc"><label for="dpw">Konfirmasi kata sandi</label><input id="dpw" name="password" type="password" required><button class="danger">Hapus akun saya</button></form></div>`)}
async function route(){const p=(location.hash.replace('#/','').split('?')[0]||'dash').split('/');
 if(!user){try{user=(await api('/me')).user}catch{return authView()}}
 try{const k=p[0];if(k==='dash')await dash();else if(TOOLS[k])tool(k);else if(k==='interview')interview();else if(k==='history')await hist(p[1]);else if(k==='settings')settings();else location.hash='#/dash'}catch(e){toast(e.message,1)}}
const form=f=>Object.fromEntries(new FormData(f));
const H={
 async login(f){const r=await api('/login','POST',form(f));user=r.user;location.hash='#/dash';route()},
 async register(f){const r=await api('/register','POST',form(f));user=r.user;location.hash='#/dash';route()},
 async tool(f){const k=f.dataset.tool,r=await api('/ai/'+k,'POST',form(f));document.getElementById('out').innerHTML=`<div class="card out">${show(k,r.output)}</div><button class="ghost" data-act="copy" data-id="${r.id}">Salin teks</button><span class="mu">Tersimpan di Riwayat</span>`;fillBars();toast('Selesai dibuat')},
 async ivstart(f){window.iv={...form(f),qs:[],fb:null,log:[]};await ivq()},
 async ivans(f){const s=window.iv,a=form(f).answer,r=await api('/ai/interview/feedback','POST',{role:s.role,question:s.qs.at(-1),answer:a});s.log.push(`P: ${s.qs.at(-1).slice(0,250)}\nJ: ${a.slice(0,400)}\nSkor/umpan balik: ${r.output.slice(0,450)}`);s.fb=r.output;interview()},
 async profile(f){user=(await api('/profile','PUT',form(f))).user;toast('Profil disimpan')},
 async pw(f){await api('/password','PUT',form(f));f.reset();toast('Kata sandi diubah')},
 async delacc(f){if(!confirm('Hapus akun secara permanen?'))return;await api('/account','DELETE',form(f));user=null;authView()}};
document.addEventListener('submit',async e=>{const f=e.target,fn=H[f.dataset.form];if(!fn)return;e.preventDefault();const b=f.querySelector('button:last-of-type'),er=f.querySelector('#err');if(er)er.textContent='';
 b.disabled=true;const t=b.textContent;if(f.dataset.form==='tool'||f.dataset.form.startsWith('iv'))b.textContent='Memproses…';
 try{await fn(f)}catch(x){if(er)er.textContent=x.message;else toast(x.message,1)}finally{if(b.isConnected){b.disabled=false;b.textContent=t}}});
document.addEventListener('click',async e=>{const a=e.target.closest('[data-act]');if(!a)return;e.preventDefault();const id=a.dataset.id;
 try{switch(a.dataset.act){
  case'logout':await api('/logout','POST',{});user=null;window.iv=null;authView();break;
  case'tologin':authView('login');break;case'toreg':authView('register');break;
  case'ivnext':a.disabled=true;await ivq();break;case'ivquit':window.iv=null;interview();break;
  case'ivend':{a.disabled=true;a.textContent='Menyusun ringkasan…';const s=window.iv,r=await api('/ai/interview/summary','POST',{role:s.role,level:s.level,transcript:s.log.join('\n\n')});window.iv=null;location.hash='#/history/'+r.id;break}
  case'copy':{const t=id&&id!=='null'?(await api('/history/'+id)).item.output:document.querySelector('.out').innerText;await navigator.clipboard.writeText(t.startsWith('{')?document.querySelector('.out').innerText:t);toast('Tersalin');break}
  case'del':if(confirm('Hapus hasil ini?')){await api('/history/'+id,'DELETE');toast('Dihapus');location.hash.startsWith('#/history/')?location.hash='#/history':route()}}}catch(x){toast(x.message,1)}});
addEventListener('hashchange',route);route();
