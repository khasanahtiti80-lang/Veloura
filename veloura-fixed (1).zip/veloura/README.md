# Veloura — Studio Brand Pribadi

Aplikasi web untuk personal branding, penulisan konten profesional, evaluasi brand, dan simulasi wawancara berbantuan Claude API.

## Persyaratan
- Node.js 18 atau lebih baru (disarankan Node.js versi LTS).
- API key Anthropic yang aktif dan akses API yang memiliki saldo/kuota.
- Koneksi internet dari komputer/server untuk menghubungi Anthropic API.

## Menjalankan di Windows
1. Ekstrak ZIP ini ke folder yang mudah ditemukan.
2. Buka folder `veloura` di terminal.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Buka `.env`, lalu isi `JWT_SECRET` dengan string acak minimal 32 karakter dan isi `ANTHROPIC_API_KEY` dengan API key milik Anda. Jangan membagikan atau mengunggah `.env`.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000` di browser.

Untuk membuat `JWT_SECRET` secara otomatis, jalankan perintah berikut di terminal:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Di Windows PowerShell, salin file contoh dengan:

```powershell
Copy-Item .env.example .env
```

Di macOS/Linux, gunakan:

```bash
cp .env.example .env
```

## Fitur
- Daftar, login, logout, dan autentikasi berbasis cookie httpOnly.
- Dashboard aktivitas dan riwayat hasil AI.
- Generator strategi personal branding.
- Content Studio untuk beberapa platform dan gaya bahasa.
- Evaluasi profil/brand dengan skor dan saran perbaikan.
- Simulasi wawancara lima pertanyaan, umpan balik, dan ringkasan sesi.
- Pengaturan profil, ganti kata sandi, dan penghapusan akun.

## Catatan keamanan dan penggunaan
- API key hanya disimpan di server melalui `.env`; jangan menaruhnya di `public/app.js` atau file frontend.
- File `.env`, database `data/`, dan `node_modules/` dikecualikan oleh `.gitignore`.
- Untuk deployment publik, aktifkan HTTPS, atur `NODE_ENV=production`, dan gunakan penyimpanan disk persisten untuk folder `data/`.
- Aplikasi membutuhkan API key Anthropic yang valid. Tanpa API key, halaman tetap dapat dibuka, tetapi fitur AI akan mengembalikan pesan bahwa konfigurasi API belum tersedia.
- Pemeriksaan sintaks JavaScript tidak sama dengan uji coba penuh. Jalankan aplikasi setelah menginstal dependensi dan lakukan pengujian daftar/login, setiap fitur AI, riwayat, dan pengaturan akun.
